﻿using System;

namespace TeamProject
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
