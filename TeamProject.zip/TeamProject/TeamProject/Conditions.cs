﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeamProject
{
    class Conditions
    {
        public string Name { get; set; }
        public double Concentration { get; set; }
    }
}
